# sockets_exercise_diagnostic

Integrantes

Nicolas Gutierrez Carreño
Diego Alejandro Rubiano Buitrago

En la carpeta 'src' aparecen tanto la carpeta 'client' como la carpeta 'server'

Para ejecutar el programa es por interfaz de consola

En primer lugar ejecutamos 'server'.
Cada que ejecutamos el archivo 'client' ingresara el cliente al servidor y escogera una de las dos funcionalidades
